-- phpMyAdmin SQL Dump
-- version 3.3.7deb1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 05 Novembre 2010 à 00:22
-- Version du serveur: 5.1.49
-- Version de PHP: 5.3.3-1ubuntu9.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `kinaf`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`id`, `nom`, `prenom`, `login`, `password`, `Level`) VALUES
(1, 'Verbinnen', 'Christophe', 'djpate', 'ade972a26def473f900b4a5e06093f0d1d2ca028a0e2f151eb8c79aca19b0426c9aecf0292cd8b3521ecd9df45913eb90a888c4ac538a01211f01f63e22c61d7', 1);

-- --------------------------------------------------------

--
-- Structure de la table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `level`
--

INSERT INTO `level` (`id`, `designation`) VALUES
(1, 'Super Admin'),
(2, 'Admin');

-- --------------------------------------------------------

--
-- Structure de la table `pageadmin`
--

CREATE TABLE IF NOT EXISTS `pageadmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `moduleTitle` varchar(50) NOT NULL,
  `pageTitle` varchar(50) NOT NULL,
  `rewriteUrl` varchar(100) NOT NULL,
  `file` varchar(50) NOT NULL,
  `onMenu` tinyint(1) NOT NULL,
  `isWrapped` tinyint(1) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `pageadmin`
--

INSERT INTO `pageadmin` (`id`, `parent`, `moduleTitle`, `pageTitle`, `rewriteUrl`, `file`, `onMenu`, `isWrapped`, `order`) VALUES
(1, 0, 'dashboard', 'Dashboard', 'main', '', 1, 0, 1),
(2, 1, '', 'Dashboard', 'dashboard', 'dashboard.php', 1, 1, 1),
(3, 0, 'configuration', 'Configuration global', 'configuration', '', 1, 0, 2),
(4, 3, '', 'Paramètres du site', 'parametre', 'parametre.php', 1, 1, 1),
(8, 7, '', 'Gestions des utilisateurs', 'gestion_utilisateurs', 'utilisateurs.php', 1, 1, 1),
(7, 0, 'utilisateur', 'Utilisateurs', 'utilisateurs', '', 1, 0, 3),
(9, 7, '', 'Gestions des niveaux', 'gestion_niveaux', 'niveaux.php', 1, 1, 2),
(11, 7, '', 'Gestions des droits', 'gestion_droits', 'droits.php', 1, 1, 3),
(12, 1, '', '', 'ajax', 'ajax.php', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `pageadmin_droit`
--

CREATE TABLE IF NOT EXISTS `pageadmin_droit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Pageadmin` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `pageadmin_droit`
--

INSERT INTO `pageadmin_droit` (`id`, `Pageadmin`, `Level`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 7, 1),
(6, 8, 1),
(7, 9, 1),
(8, 11, 1),
(10, 12, 1);

-- --------------------------------------------------------

--
-- Structure de la table `parametre`
--

CREATE TABLE IF NOT EXISTS `parametre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(200) NOT NULL,
  `valeur` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `parametre`
--

INSERT INTO `parametre` (`id`, `designation`, `valeur`) VALUES
(1, 'Url du site', 'http://localhost/kinaf'),
(4, 'Racine du site', '/var/www/kinaf');
